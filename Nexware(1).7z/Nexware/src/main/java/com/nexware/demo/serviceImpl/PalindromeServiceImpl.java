package com.nexware.demo.serviceImpl;

import com.nexware.demo.entity.PalindromeEntity;
import com.nexware.demo.repository.PalindromeRepository;
import com.nexware.demo.service.PalindromeService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.Optional;


@Service
@Transactional
public class PalindromeServiceImpl implements PalindromeService {
    private static final Logger LOGGER = LoggerFactory.getLogger(PalindromeServiceImpl.class);
    @Autowired
    private PalindromeRepository palindromeRepository;


    public List<PalindromeEntity> getValueFromPalindrome(){
        List<PalindromeEntity> palindromeEntityOptional =   palindromeRepository.findAll();
        return palindromeEntityOptional;
    }
    public PalindromeEntity savePalindromeValues(String value) throws Exception {
        PalindromeEntity palindromeEntity = new PalindromeEntity();
        PalindromeEntity p1 = palindromeRepository.findByList(value);
        String reverse = "";
        for (int i = value.length() - 1; i >= 0; i--) {
            reverse += value.charAt(i);
        }
        try {
            if (reverse.equals(value) && value.length() <= 100 && p1 == null) {
                palindromeEntity.setList(value);
                palindromeRepository.saveAndFlush(palindromeEntity);
                return palindromeEntity;
            }
        } catch (Exception e) {
            LOGGER.error("Error occured while saving data " + e);
        }
            return palindromeEntity;
    }

    public PalindromeRepository getPalindromeRepository() {
        return palindromeRepository;
    }

    public void setPalindromeRepository(PalindromeRepository palindromeRepository) {
        this.palindromeRepository = palindromeRepository;
    }
}

