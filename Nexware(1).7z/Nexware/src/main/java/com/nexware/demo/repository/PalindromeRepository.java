package com.nexware.demo.repository;

import com.nexware.demo.entity.PalindromeEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

@Repository
@Transactional
public interface PalindromeRepository extends JpaRepository<PalindromeEntity, Long> {
    PalindromeEntity findByList(@Param("list") String list);
}
