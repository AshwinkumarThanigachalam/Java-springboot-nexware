package com.nexware.demo.controller;

import com.nexware.demo.entity.PalindromeEntity;
import com.nexware.demo.repository.PalindromeRepository;
import com.nexware.demo.service.PalindromeService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping(value = "/palindrome")
public class PalindromeController {
    private PalindromeService palindromeService;
    private PalindromeRepository palindromeRepository;

    @GetMapping(value = "/values",produces = "application/json")
    public List<PalindromeEntity> getValuesFromDb(){
         List<PalindromeEntity> palindromeEntities = palindromeService.getValueFromPalindrome();
         return palindromeEntities;
    }
    @PostMapping(value = "/save/{palindrome}",produces = "application/json",consumes = "application/json")
    public PalindromeEntity savePalindromeValues(@PathVariable("palindrome") String palindrome) throws Exception{
        PalindromeEntity palindromeEntity =  palindromeService.savePalindromeValues(palindrome);
        return palindromeEntity;
    }
    @Autowired
    public void setPalindromeService(PalindromeService palindromeService) {
        this.palindromeService = palindromeService;
    }
    @Autowired
    public void setPalindromeRepository(PalindromeRepository palindromeRepository) {
        this.palindromeRepository = palindromeRepository;
    }
}
