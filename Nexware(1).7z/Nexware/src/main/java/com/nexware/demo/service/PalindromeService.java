package com.nexware.demo.service;

import com.nexware.demo.entity.PalindromeEntity;

import java.util.List;

public interface PalindromeService {
    List<PalindromeEntity> getValueFromPalindrome();
    PalindromeEntity savePalindromeValues(String value) throws Exception;
}
